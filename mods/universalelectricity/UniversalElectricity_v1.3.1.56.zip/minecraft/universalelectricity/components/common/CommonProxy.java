package universalelectricity.components.common;

public class CommonProxy
{
	public void preInit()
	{
	}

	public void init()
	{
		BasicComponents.registerTileEntities();
	}
}
