Fancy Glass was created by Darkmainiac. Thanks for downloading, enjoy.

Modpacks: 
Feel free to add this mod to your Mod Pack, so long as credit is given to me for 
making the mod and you link to the original forum post if at all possible:
http://www.minecraftforum.net/topic/1653291-1467-forge-1000-downloads-fancy-glass-v103/

If you have downloaded this from any site other than the link at Minecraft Forum page listed above, please delete this zip file and get it from there.
No other site is authorized to share the file and there for should not be trusted.

Forge is required (recommended Build 7.7.0.595 or above).
Installation:
Put the FancyGlass-(VERSION).zip into your "mods" directory after installing Forge.

Legal Stuff:
This document is Copyright �(2013) Darkmainiac and is the intellectual
property of the author. Only Minecraftforum.net is able to host any of my material 
without my(Darkmainiac) consent. It may not be placed on any web site or otherwise 
distributed publicly without advance written permission. If you mirror this mod page 
or anything I've(Darkmainiac) made on any other site, I(Darkmainiac) may express my 
angst at you in the form of a lawsuit.

Follow me on twitter @darkmainiac for up-to-date info on this mod in case something
changes.

Thank you,
Darkmainiac


